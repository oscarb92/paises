<?php

/**
 * Credits for Woocommerce Uninstall
 *
 * Uninstalling Credits for Woocommerce deletes plugin data.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit ;
}

wp_clear_scheduled_hook( 'wc_cs_credits_background_process' ) ;

