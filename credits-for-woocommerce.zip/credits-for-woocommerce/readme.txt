=== Credits for WooCommerce ===
Contributors: FantasticPlugins
Tags: credits for woocommerce, woocommerce credits plugin
Requires at least: 4.6
Tested up to: 5.4.2
Requires PHP: 5.6
Stable tag: 2.0

